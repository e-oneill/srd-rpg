using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace SA
{
public class SessionManager : MonoBehaviour

    {
        int turnIndex;
        public Turn[] turns;
        public bool turnCombat = false;
        public Transform gridObject;
        public GridCharacter activeChar;

        public GridManager gridManager;

        public float delta;
        public LineRenderer pathViz;
        public Node storedCharacterLoc;
        
        bool isPathfinding;
        bool isInit;

        #region Init
        private void Start()
        {
            gridManager.Init();
            
            InitStateManagers();
            placeUnits();
            isInit = true;
        }
        void InitStateManagers()
        {
            foreach (Turn t in turns)
            {
                t.player.Init();
            }
        }
        void placeUnits()
        {
            GridCharacter[] units = GameObject.FindObjectsOfType<GridCharacter>();
            foreach (GridCharacter u in units)
            {
                u.OnInit();
                Node n;
                Vector3 CharacterPositionHelper = u.transform.position;
                
                // Debug.Log(CharacterPositionHelper);
                turnCombat = true;

                n = gridManager.GetNode(CharacterPositionHelper);
                //Arbitrarily subtracting 1 for the y coordinates of the node the character is believed to be in. Believe this is necessary because pivot point of character model used during testing and dev is in center.
                n.y = n.y-gridManager.characterYOffset;

                
                if (n != null)
                {
                    Vector3 CharacterPlacer = n.worldPosition;
                    //Doing the offset because of the strange 1 unit offset with the grid location find.
                    // CharacterPlacer.x += gridManager.globalOffset;
                    // CharacterPlacer.z += gridManager.globalOffset;

                    u.transform.position = CharacterPlacer;
                    n.character = u;
                    gridManager.SetNodeCharacter(n.x, n.y, n.z, u);
                    // Debug.Log ("Character should be placed on the Grid");
                    u.currentNode = n;
                    Debug.Log("Character: " + n.character + "Character Location in grid: " + n.x + ", " + n.z + ", " + n.y);
                    storedCharacterLoc = n;
                    
                }
            }
        }

        #endregion

        #region Pathfinding Calls
        public void PathfinderCall(GridCharacter c, Node targetNode)
        {
            if (!isPathfinding)
            {
                isPathfinding = true;
                
                
                Node start = c.currentNode;
                Node target = targetNode;
                // Debug.Log("Current Node attempting Pathfinder Call: " + start + "Target Node:" + targetNode);
                if (start != null && target !=null)
                {
                
                PathfinderMaster.singleton.RequestPathfind(c, start, target, PathfinderCallback, gridManager);
                }
                else
                {
                    isPathfinding = false;
                }
            }


        }

        void PathfinderCallback(List<Node> p, GridCharacter character)
        {
            // Debug.Log("Pathfinder Callback Called. List:" + p + " Character:" + character);

            isPathfinding = false;
            if (p == null)
            {
                Debug.LogWarning("Path is not valid");
                return;
            }
            else
            {
                // Debug.Log("Path returned.");
            }
            Vector3 offset = Vector3.right *.2f + Vector3.down * .8f;
            pathViz.positionCount = p.Count + 1;
            if (pathViz.positionCount > character.moveRemaining)
            {
                Debug.Log("Path was longer than character's movement. Limiting to character speed of " + character.racialsBlock.charMovement*5);
                pathViz.positionCount = character.moveRemaining + 1;
            }



            List<Vector3> allPositions = new List<Vector3>();
            allPositions.Add(character.currentNode.worldPosition + offset);
            for (int i = 0; i < p.Count; i++)
            {
                allPositions.Add(p[i].worldPosition + offset);
            }
            
            character.LoadPath(p);

            pathViz.SetPositions(allPositions.ToArray());

        }

        public void ClearPath()
        {
            pathViz.positionCount = 0;
        }
        #endregion
        
        

        // public Node currentNode;

       #region Frame Update
        private void Update()
        {
            delta = Time.deltaTime;
            if (!isInit) return;
            
            if (turns[turnIndex].Execute(this))
            {
                turnIndex++;
                if(turnIndex > turns.Length-1)
                {
                    turnIndex = 0;
                }
            }
        }
        #endregion
    }
}
