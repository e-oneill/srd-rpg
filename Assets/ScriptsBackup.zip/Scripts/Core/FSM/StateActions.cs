using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//this script executes a state and passes the other objects we need.

namespace SA
{
    public abstract class StateActions
    {
        public abstract void Execute(StateManager states, SessionManager sm, Turn t);
    }
}
