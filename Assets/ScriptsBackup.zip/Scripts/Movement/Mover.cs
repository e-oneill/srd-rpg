using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class Mover : MonoBehaviour
{
    [SerializeField] Transform Target;



    // Update is called once per frame
    void Update()
    {
 
        UpdateAnimator();

        // GetComponent<NavMeshAgent>().destination = Target.position;
    }



    public void MoveTo(Vector3 destination)
    {
        GetComponent<NavMeshAgent>().destination = destination;
        NavMeshPath nextpath = GetComponent<NavMeshAgent>().path;
        GetComponent<NavMeshAgent>().CalculatePath(destination, nextpath);
        float pathdistance = GetComponent<NavMeshAgent>().remainingDistance;
        // Debug.Log("Distance to destination: " + pathdistance);
    }

    private void UpdateAnimator()
    {
        Vector3 velocity = GetComponent<NavMeshAgent>().velocity;
        Vector3 localVelocity = transform.InverseTransformDirection(velocity);
        float speed = localVelocity.z;
        GetComponent<Animator>().SetFloat("ForwardSpeed", speed);
    }
}
