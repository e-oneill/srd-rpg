using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace SA
{
public class PlayerController : MonoBehaviour
{
    public SessionManager sessionManager;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButton(0))
        {
            MoveToCursor();
           // Debug.DrawRay(lastRay.origin, lastRay.direction * 100);
        }   
    }

    private void MoveToCursor()
    {
        if (!sessionManager.turnCombat)
        {
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;
            bool hasHit = Physics.Raycast(ray, out hit);
            if (hasHit)
            {
                GetComponent<Mover>().MoveTo(hit.point);
            }
        }
        else 
        {
            
        }
    }
}
}
